package ggkaw.caces.garnhge;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        URL weatherURL = new wetmeupbigboi("02215").dotheweter();
//        Log.i(TAG, "onCreate: weatherUrl: " + weatherURL);




    }

    public void ClickButt(View view) throws ExecutionException, InterruptedException {

        String sZipCode;
        EditText mStrang = (EditText) findViewById(R.id.Strang);
        TextView mDisplay_View = (TextView) findViewById(R.id.Display_View);
        sZipCode = mStrang.getText().toString();
        String dat = new GetData().execute(sZipCode).get();
//        RequestQueue mRequestQueue;

//      WeatherHttpClient Weather = new WeatherHttpClient(sZipCode);
//      output = Weather.getWeatherData();
        String weatherparta = dat.substring(dat.indexOf("{"), dat.indexOf("description\""));
        dat = dat.replace(weatherparta, "");
        dat = dat.replace("description\"","");
        weatherparta = dat.substring(dat.indexOf(":"), dat.indexOf(","));
        weatherparta = weatherparta.replace(":\"", "");
        dat = dat.replace(weatherparta, "");
        weatherparta = weatherparta.replace("\"", "");
        String forecast = weatherparta; //forecast
        weatherparta = dat.substring(dat.indexOf(":"), dat.indexOf(","));
        dat = dat.replace(weatherparta, "");
        weatherparta = dat.substring(dat.indexOf(","), dat.indexOf("{")+1);
        dat = dat.replace(weatherparta, "");
        weatherparta = dat.substring(dat.indexOf("\""), dat.indexOf(":"));
        dat = dat.replace(weatherparta, "");
        weatherparta = dat.substring(dat.indexOf(":"), dat.indexOf(","));
        dat = dat.replace(weatherparta, "");
        weatherparta = weatherparta.replace(":", "");
        String tempString = weatherparta;
        mDisplay_View.setText("Temperature: " + weatherparta);
        weatherparta = dat.substring(dat.indexOf(","), dat.indexOf(":"));
        dat = dat.replace(weatherparta, "");
        weatherparta = dat.substring(dat.indexOf(":"), dat.indexOf("\""));
        dat = dat.replace(weatherparta, "");
        weatherparta = dat.substring(dat.indexOf("\""), dat.indexOf(":"));
        dat = dat.replace(weatherparta, "");
        weatherparta = dat.substring(dat.indexOf(":"), dat.indexOf(","));
        dat = dat.replace(weatherparta, "");
        weatherparta = weatherparta.replace(":", "");
        String humidity = weatherparta;
        double tempNum = Double.parseDouble(tempString);
        tempNum = (tempNum-273)*(9/5) + 32;
        tempString = String.format("%.2f", tempNum);
        mDisplay_View.setText("Forecast: " + forecast +"\nTemperature: " + tempString + "\u00b0" + "F" + "\nHumidity: " + humidity + "%");




    }
}
