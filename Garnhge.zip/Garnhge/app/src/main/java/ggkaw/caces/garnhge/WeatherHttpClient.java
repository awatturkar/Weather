package ggkaw.caces.garnhge;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherHttpClient/* extends AsyncTask<Void,Void,Void>*/ {
    private static String sZip;
    private static String BASE_URL = ("http://api.openweathermap.org/data/2.5/weather?zip=");
    private static String API_KEY = ",us&APPID=880e041b4a395ef756fa25edb3b7f54d";
    private static String URL_STRING;

    public WeatherHttpClient(String zipCode)
    {
        this.sZip = zipCode;
        this.URL_STRING = BASE_URL + sZip + API_KEY;
    }

//    private static String IMG_URL = "http://openweathermap.org/img/w";




    public static String getWeatherData() {

        HttpURLConnection con = null;
        InputStream is = null;

        try {
            con = (HttpURLConnection) (new URL(URL_STRING)).openConnection();
            con.setRequestMethod("GET");
            con.setDoInput(true);
            con.setDoOutput(true);
            con.connect();

            //Read response
            StringBuffer buffer = new StringBuffer();
            is = con.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = null;
            while ((line = br.readLine()) != null)
                buffer.append(line + "\r\n");
            is.close();
            con.disconnect();
            return buffer.toString();
        } catch (Throwable t) {
            t.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (Throwable t) {
            }
            try {
                con.disconnect();
            } catch (Throwable t) {
            }

        }
        return null;
    }



}
