package ggkaw.caces.garnhge;

import android.net.Uri;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class wetmeupbigboi {
    private static final String TAG = "wetmeupbigboi";
    private final static String BEGIN_URL= "http://api.openweathermap.org/data/2.5/weather?zip=";
    private static String zipCode;
    private static String API_URL;
    private final static String API_KEY = "880e041b4a395ef756fa25edb3b7f54d";
    private final static String PARAM_API_KEY ="apikey";

    public wetmeupbigboi(String zipCode){
         String API_URL = BEGIN_URL+ this.zipCode + ",us&APPID=";
    }
    public static URL dotheweter(){
        Uri builtUri = Uri.parse(API_URL).buildUpon().appendQueryParameter(PARAM_API_KEY,API_KEY).build();

        URL url = null;

        try {
            url = new URL(builtUri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Log.i(TAG, "buildURlForWeather:" + url);
        return url;
    }

    public static String getResponseFromHttpUrl(URL url) throws IOException {
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try{
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);

            boolean hasInput = scanner.hasNext();
            if(hasInput){
                return scanner.next();
            } else {
                return null;
            }
            } finally {
                urlConnection.disconnect();
            }

        }
    }

